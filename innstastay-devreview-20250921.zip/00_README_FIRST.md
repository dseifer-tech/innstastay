﻿# InnstaStay - Developer Review Bundle

**Stack:** Next.js 14 (App Router) + TypeScript + TailwindCSS + Sanity CMS

InnstaStay shows official hotel prices and policies, then sends users to the hotel to book directly. No reselling, no platform fees.

## Quick Start

```bash
# Prerequisites: Node.js 18+ (recommended: 20+)
npm install

# Setup environment
cp .env.example .env.local
# Edit .env.local with your API keys, or leave OFFLINE_MODE=true for demo

# Development
npm run dev
# Visit http://localhost:3000

# Production build
npm run build
npm start
```

## Offline Mode (Default)

When `OFFLINE_MODE=true` or API keys are missing:
- ✅ Hotel data comes from `/data/hotels.sample.json`
- ✅ Pricing data comes from `/data/pricing.sample.json`  
- ✅ All pages render with sample data
- ✅ No external API calls made
- ✅ Full functionality demonstration

## Project Structure

- `/app/` - Next.js App Router (pages, API routes, components)
  - `page.tsx` - Homepage with featured hotels
  - `search/` - Hotel search and results
  - `hotels/[slug]/` - Individual hotel pages
  - `api/` - API routes (hotels, search, pricing)
  - `components/` - React components
- `/lib/` - Business logic, utilities, adapters
  - `hotelSource.ts` - **MAIN DATA SOURCE** integration layer
  - `hotels.ts` - Hotel fetching utilities
  - `services/pricing.server.ts` - Live pricing integration
- `/types/` - TypeScript definitions (Hotel, Money, etc.)
- `/data/` - Sample data for offline mode
- `/public/` - Static assets (logos, images)

## Key Features

### 🏨 Hotel Management
- Sanity CMS for hotel content management
- Sample hotels: Hotel Riu Plaza Toronto, Westin Harbour Castle, Fairmont Royal York
- Rich metadata: ratings, amenities, images, SEO

### 💰 Live Pricing
- SerpApi integration for real-time Google Hotels pricing
- Fallback to sample pricing data in offline mode
- Official booking links direct to hotels

### 🎨 UI/UX
- Modern, responsive design with TailwindCSS
- Accessible components with proper ARIA labels
- Optimized images with Next.js Image component

### 🔧 Architecture
- App Router with server components
- Type-safe with comprehensive TypeScript
- Proper error boundaries and loading states
- Image proxy for external hotel images

## Environment Variables Needed

**For Full Functionality:**
- `SERPAPI_KEY` - Google Hotels pricing data
- `SANITY_API_TOKEN` - CMS content management
- `NEXT_PUBLIC_SANITY_PROJECT_ID` - Sanity project ID

**See `.env.example` for complete configuration**

## Available Scripts

- `npm run dev` - Development server
- `npm run build` - Production build  
- `npm run start` - Production server
- `npm run lint` - ESLint check
- `npm run test` - Jest tests

## Known Limitations / TODOs

1. **Sample Data**: Replace `/data/*.json` with live API integration
2. **Image Optimization**: Some external hotel images may need proxy configuration
3. **SEO**: Sitemap generation requires live data
4. **Analytics**: Integration points ready but not configured

## API Integration Points

### SerpApi (Google Hotels)
- **Purpose**: Real-time hotel pricing and availability
- **Files**: `lib/services/pricing.server.ts`
- **Fallback**: `data/pricing.sample.json`

### Sanity CMS  
- **Purpose**: Hotel content management
- **Files**: `lib/sanity.client.ts`, `lib/hotelSource.ts`
- **Fallback**: `data/hotels.sample.json`

## Development Notes

- **Image Proxy**: External hotel images routed through `/api/hotel-images` for optimization
- **Pricing Cache**: Results cached in `/logs/` directory during development
- **Error Handling**: Graceful fallbacks throughout, never blocks page render
- **Performance**: Server components used where possible, client components minimal

---

🚀 **Ready to explore!** Start with `npm run dev` and visit the homepage.