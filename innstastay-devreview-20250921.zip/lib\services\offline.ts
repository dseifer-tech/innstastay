/**
 * Offline mode data service
 * Provides sample data when OFFLINE_MODE=true or API keys are missing
 */

import { readFileSync } from 'fs';
import { join } from 'path';
import type { Hotel } from '@/types/hotel';

let cachedHotels: any[] | null = null;
let cachedPricing: any | null = null;

export function isOfflineMode(): boolean {
  return (
    process.env.OFFLINE_MODE === 'true' ||
    !process.env.SERPAPI_KEY ||
    !process.env.SANITY_API_TOKEN ||
    process.env.SANITY_API_TOKEN === '__REPLACE_WITH_SANITY_API_TOKEN__'
  );
}

export function getOfflineHotels(): any[] {
  if (cachedHotels) return cachedHotels;
  
  try {
    const dataPath = join(process.cwd(), 'data', 'hotels.sample.json');
    const data = readFileSync(dataPath, 'utf-8');
    cachedHotels = JSON.parse(data);
    return cachedHotels;
  } catch (error) {
    console.warn('Could not load offline hotel data:', error);
    return [];
  }
}

export function getOfflinePricing(): any {
  if (cachedPricing) return cachedPricing;
  
  try {
    const dataPath = join(process.cwd(), 'data', 'pricing.sample.json');
    const data = readFileSync(dataPath, 'utf-8');
    cachedPricing = JSON.parse(data);
    return cachedPricing;
  } catch (error) {
    console.warn('Could not load offline pricing data:', error);
    return {};
  }
}

export function getOfflinePricingForToken(token: string): any {
  const pricing = getOfflinePricing();
  return pricing[token] || {
    nightlyFrom: 299,
    currency: 'CAD',
    officialLink: 'https://example.com/booking',
    rooms: [
      {
        name: 'Standard Room',
        link: 'https://example.com/booking',
        nightly: 299,
        currency: 'CAD',
        refundable: true,
        cancellable: true,
        ratePlan: 'Best Available Rate'
      }
    ]
  };
}
