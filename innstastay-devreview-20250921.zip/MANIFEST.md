# InnstaStay Developer Review Bundle - Manifest

**Bundle Date:** 2025-09-21  
**Framework:** Next.js 14 + TypeScript + TailwindCSS

## File Structure & Purpose

### 📁 Root Configuration Files
- `00_README_FIRST.md` - **START HERE** - Setup and overview
- `.env.example` - Environment variables template with safe placeholders
- `MANIFEST.md` - This file - complete bundle documentation
- `package.json` - NPM dependencies and scripts
- `package-lock.json` - Dependency lock file for reproducible installs
- `next.config.js` - Next.js configuration (CSP, redirects, headers)
- `tsconfig.json` - TypeScript configuration
- `tailwind.config.js` - TailwindCSS configuration with custom theme
- `postcss.config.js` - PostCSS configuration for Tailwind
- `next-env.d.ts` - Next.js TypeScript definitions
- `middleware.ts` - Next.js middleware (auth, CSP, redirects)

### 📁 app/ - Next.js App Router Structure
**Pages & Routes:**
- `page.tsx` - Homepage with featured hotels and search
- `layout.tsx` - Root layout with navigation and metadata
- `not-found.tsx` - 404 error page
- `globals.css` - Global styles and Tailwind imports
- `fonts.ts` - Font loading configuration
- `HomePageClient.tsx` - Client-side homepage components
- `robots.ts` - Dynamic robots.txt generation

**Route Groups:**
- `about/page.tsx` - About page
- `contact/` - Contact pages and components
- `search/` - Hotel search and results pages
- `hotels/[slug]/page.tsx` - Dynamic hotel detail pages
- `downtown-toronto/` - Location-specific pages
- `privacy/page.tsx` - Privacy policy

**API Routes:**
- `api/hotels/route.ts` - Hotel data endpoint
- `api/hotel-images/route.ts` - Image proxy for external hotel images
- `api/admin/` - Admin endpoints for hotel management
- `api/cms/` - CMS integration endpoints

**Components:**
- `components/` - 36 React components including:
  - UI components (Button, Modal, Navigation)
  - Hotel components (HotelCard, SearchResults, PriceBadge)
  - Layout components (Header, Footer, SearchBar)
  - Form components (RangeDatePicker, Filters)

### 📁 lib/ - Business Logic & Utilities
**Core Files:**
- `hotelSource.ts` - **MAIN DATA SOURCE** - Hotel fetching and enrichment
- `hotels.ts` - Hotel data utilities
- `sanity.client.ts` - Sanity CMS client configuration
- `queries.ts` - GROQ queries for Sanity
- `constants.ts` - App-wide constants
- `utils.ts` - General utilities

**Feature Modules:**
- `services/pricing.server.ts` - Live pricing integration (SerpApi)
- `adapters/sanityHotel.ts` - Data adapter for Sanity hotel documents
- `bookingLink.ts` - Hotel booking URL generation
- `img.ts` - Image optimization utilities
- `security.ts` - Security utilities and validation
- `seo.ts` - SEO metadata generation

**Infrastructure:**
- `core/` - Core utilities (logging, concurrency, validation)
- `crypto/` - Cryptographic utilities
- `url/` - URL utilities and base URL handling
- `live/` - Live data integration
- `toronto/` - Toronto-specific data and utilities

### 📁 types/ - TypeScript Definitions
- `hotel.ts` - Hotel, HotelRoom, SearchParams interfaces
- `money.ts` - Money type and currency formatting

### 📁 data/ - Sample Data (Offline Mode)
- `hotels.sample.json` - 3 sample Toronto hotels with redacted tokens
- `pricing.sample.json` - Sample pricing data matching hotel tokens

### 📁 public/ - Static Assets
- `logo.png` - InnstaStay logo
- `favicon.ico` - Site favicon
- `hero/` - Hero images for homepage
- `og/` - OpenGraph images for social sharing

## Intentionally Excluded Files

### 🚫 Security & Secrets
- `.env*` files (except `.env.example`) - Contains real API keys
- `logs/` directory - Contains real pricing data and tokens

### 🚫 Build Artifacts & Dependencies
- `node_modules/` - NPM dependencies (installed via `npm install`)
- `.next/` - Next.js build output
- `dist/` - Build artifacts
- `.turbo/` - Turborepo cache
- `tsconfig.tsbuildinfo` - TypeScript build cache

### 🚫 Development Tools
- `.git/` - Git repository (not needed for review)
- `tests/` - Test files (Jest setup present in package.json)
- `scripts/` - Build scripts and utilities (19 files excluded)
- `sanity/` - Sanity Studio configuration
- Various config files: `jest.config.js`, `playwright.config.ts`

### 🚫 Documentation & Research
- `README.md` - Original project README (replaced with `00_README_FIRST.md`)
- `CLEANUP_REPORT.md`, `SESSION_NOTES.md`, `SUMMARY.md` - Development notes
- `reserch.xlsx` - Research file

## Key Architecture Notes

### Data Flow
1. **Hotel Data**: Sanity CMS → `lib/hotelSource.ts` → Components
2. **Pricing Data**: SerpApi → `lib/services/pricing.server.ts` → Hotel enrichment
3. **Offline Mode**: `/data/*.json` → Same flow as live data

### Security Measures
- Content Security Policy in `next.config.js`
- Image proxy for external hotel images
- Rate limiting and CORS protection
- Input validation with Zod schemas

### Performance Optimizations
- Server components where possible
- Image optimization with Next.js Image
- Static generation for stable pages
- Lazy loading for search results

## Sample Data Details

### Hotels (`data/hotels.sample.json`)
- **Hotel Riu Plaza Toronto** - Financial District, 4-star
- **The Westin Harbour Castle** - Harbourfront, 4-star luxury
- **Fairmont Royal York** - Downtown, 5-star historic

### Pricing (`data/pricing.sample.json`)
- CAD pricing for Toronto market
- Room type variations
- Booking policies (refundable/cancellable)

**Note**: All property tokens redacted (`REDACTED_TOKEN_*`) for security.

## Development Workflow

1. **Install**: `npm install`
2. **Configure**: Copy `.env.example` to `.env.local`
3. **Develop**: `npm run dev` (uses sample data by default)
4. **Build**: `npm run build && npm start`
5. **Test**: Navigate to `/`, `/search`, `/hotels/hotel-riu-plaza-toronto`

## Bundle Validation Checklist

- ✅ All essential source files included
- ✅ No secrets or credentials included
- ✅ Sample data enables full functionality
- ✅ Dependencies listed in package.json
- ✅ Clear setup instructions provided
- ✅ Offline mode works without API keys
- ✅ Build process documented

**Total Files**: ~140 source files + configuration
**Bundle Size**: <5MB (excluding node_modules)
**Setup Time**: <5 minutes with Node.js installed
