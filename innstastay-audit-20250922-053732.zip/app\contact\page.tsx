import ContactPageClient from './ContactPageClient'

export const dynamic = 'force-static';

export default function ContactPage() {
  return <ContactPageClient />
}
